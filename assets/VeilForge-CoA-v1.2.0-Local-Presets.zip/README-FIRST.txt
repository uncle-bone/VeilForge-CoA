VeilForge-CoA v1.2.0 — LOCAL PRESET BUILD (NOT AN IN-GAME UI MOD)

DEFAULT: Level 2/10 (subtle visual changes) is installed in CoAVolFog.ini.

HOW TO USE
1. Close game, back up your existing graphics DLLs and CoAVolFog.ini.
2. Extract all ZIP contents directly into the folder containing Ascension.exe.
3. Run VeilForge-Setup.cmd to generate game-derived data (if not already done).
4. Run VeilForge-Preset-Selector.cmd and choose a level from 1 to 10.
5. Launch the game. Ctrl+F7 opens the ORIGINAL renderer's advanced settings.

IMPORTANT LIMITATION: The existing Ctrl+F7 interface is compiled inside CoAVolFog.dll.
This package does NOT modify the DLL or add a slider inside Ctrl+F7. The included
Windows preset selector edits CoAVolFog.ini, which the renderer reads.

The presets are deliberately conservative, not performance benchmark calibrated.
They manage 60+ settings, preserving other settings including custom zone lists,
keybindings, color balance, and unsafe sun/moon shaft controls. Levels 1-10
are complete config snapshots; the selector merges managed values into the current
file and backs up the initial user settings once for restore.

Known artifact-prone LightShafts, TerrainShadows and GodRays remain OFF for all levels.
No GPU benchmark or Windows in-game test has been performed. High levels may cost FPS.
You can edit individual settings using Ctrl+F7 and Save after applying a preset.

Upstream: https://github.com/lumenveil/Lumenveil
Maintainer: Uncle Bone — https://github.com/uncle-bone
Retain all bundled licenses and third-party notices.
