@echo off
setlocal
echo VeilForge-CoA Graphics Presets (1-10)
echo 2 = subtle default; 5 = balanced; 6 = golden standard
set /p LEVEL=Enter a level 1-10 (or R to restore original): 
if /I "%LEVEL%"=="R" (powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0VeilForge-Apply-Preset.ps1" -Restore) else (powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0VeilForge-Apply-Preset.ps1" -Level %LEVEL%)
pause
