param([ValidateRange(1,10)][int]$Level=2,[switch]$Restore)
$ErrorActionPreference='Stop'
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$target=Join-Path $here 'CoAVolFog.ini'
$backup=Join-Path $here 'VeilForge-User-Backup.ini'
if($Restore){
 if(!(Test-Path $backup)){throw 'No saved user backup exists.'}
 Copy-Item -LiteralPath $backup -Destination $target -Force
 Write-Host 'Original user settings restored. Restart game if needed.';exit 0
}
$source=Join-Path $here ('VeilForge-Presets\Level-{0:00}.ini' -f $Level)
if(!(Test-Path $source)){throw "Missing preset $source"}
if((Test-Path $target) -and !(Test-Path $backup)){Copy-Item -LiteralPath $target -Destination $backup}
# Merge only preset-managed keys, preserving user's keybinds, zones, device controls and custom overrides.
$managed=@('Quality','Density','FogCeiling','Haze','GroundFog','FarFog','DustHaze','HumidHaze','CloudShadows','CloudCover','SunScatter','Ambient','Exposure','ClassicExposure','SurfaceShadows','Drift','DriftDetail','DriftSwirl','BankCover','BankHeight','BankPool','BankShadow','MorningMist','MistHeight','EveningHaze','WeatherFog','LampFog','LampCount','LampFlicker','FireStrength','LampIndoors','FarLights','LampLight','LampDayLight','LampShadows','WindowLight','EffectLight','CorpseLight','NightDarkness','WaterReflect','WaterGlitter','WaterClarity','WaterWaves','ReliefDepth','ReliefLight','ReliefShadows','ReliefDistance','Temporal','StockFog','Banks','LightGlow','WetSurfaces','Puddles','Relief','ReliefModels','TerrainMaterials','SurfaceSheen','WaterRain','WaterMemory','LiquidDepth')
$set=@{};foreach($line in [IO.File]::ReadAllLines($source)){if($line -match '^([A-Za-z][\w]*)\s*=\s*(.*)$' -and $managed -contains $matches[1]){$set[$matches[1]]=$matches[2]}}
$lines=[IO.File]::ReadAllLines($target)
$out=foreach($line in $lines){if($line -match '^([A-Za-z][\w]*)(\s*=\s*)(.*)$' -and $set.ContainsKey($matches[1])){$matches[1]+$matches[2]+$set[$matches[1]]}else{$line}}
[IO.File]::WriteAllLines($target,[string[]]$out,(New-Object System.Text.UTF8Encoding($false)))
Write-Host "Applied VeilForge Level $Level. Ctrl+F7 advanced settings remain available."
Write-Host 'Changes are read live by renderer except restart-only settings.'
